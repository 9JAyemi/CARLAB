/*******************************************************************************
* File Name: DAC2_PM.c  
* Version 1.90
*
* Description:
*  This file provides the power management source code to API for the
*  VDAC8.  
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "DAC2.h"

static DAC2_backupStruct DAC2_backup;


/*******************************************************************************
* Function Name: DAC2_SaveConfig
********************************************************************************
* Summary:
*  Save the current user configuration
*
* Parameters:  
*  void  
*
* Return: 
*  void
*
*******************************************************************************/
void DAC2_SaveConfig(void) 
{
    if (!((DAC2_CR1 & DAC2_SRC_MASK) == DAC2_SRC_UDB))
    {
        DAC2_backup.data_value = DAC2_Data;
    }
}


/*******************************************************************************
* Function Name: DAC2_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
*******************************************************************************/
void DAC2_RestoreConfig(void) 
{
    if (!((DAC2_CR1 & DAC2_SRC_MASK) == DAC2_SRC_UDB))
    {
        if((DAC2_Strobe & DAC2_STRB_MASK) == DAC2_STRB_EN)
        {
            DAC2_Strobe &= (uint8)(~DAC2_STRB_MASK);
            DAC2_Data = DAC2_backup.data_value;
            DAC2_Strobe |= DAC2_STRB_EN;
        }
        else
        {
            DAC2_Data = DAC2_backup.data_value;
        }
    }
}


/*******************************************************************************
* Function Name: DAC2_Sleep
********************************************************************************
* Summary:
*  Stop and Save the user configuration
*
* Parameters:  
*  void:  
*
* Return: 
*  void
*
* Global variables:
*  DAC2_backup.enableState:  Is modified depending on the enable 
*  state  of the block before entering sleep mode.
*
*******************************************************************************/
void DAC2_Sleep(void) 
{
    /* Save VDAC8's enable state */    
    if(DAC2_ACT_PWR_EN == (DAC2_PWRMGR & DAC2_ACT_PWR_EN))
    {
        /* VDAC8 is enabled */
        DAC2_backup.enableState = 1u;
    }
    else
    {
        /* VDAC8 is disabled */
        DAC2_backup.enableState = 0u;
    }
    
    DAC2_Stop();
    DAC2_SaveConfig();
}


/*******************************************************************************
* Function Name: DAC2_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  DAC2_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void DAC2_Wakeup(void) 
{
    DAC2_RestoreConfig();
    
    if(DAC2_backup.enableState == 1u)
    {
        /* Enable VDAC8's operation */
        DAC2_Enable();

        /* Restore the data register */
        DAC2_SetValue(DAC2_Data);
    } /* Do nothing if VDAC8 was disabled before */    
}


/* [] END OF FILE */
