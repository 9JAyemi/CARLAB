/*******************************************************************************
* File Name: Vsync.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Vsync_H) /* Pins Vsync_H */
#define CY_PINS_Vsync_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Vsync_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Vsync__PORT == 15 && ((Vsync__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Vsync_Write(uint8 value);
void    Vsync_SetDriveMode(uint8 mode);
uint8   Vsync_ReadDataReg(void);
uint8   Vsync_Read(void);
void    Vsync_SetInterruptMode(uint16 position, uint16 mode);
uint8   Vsync_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Vsync_SetDriveMode() function.
     *  @{
     */
        #define Vsync_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Vsync_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Vsync_DM_RES_UP          PIN_DM_RES_UP
        #define Vsync_DM_RES_DWN         PIN_DM_RES_DWN
        #define Vsync_DM_OD_LO           PIN_DM_OD_LO
        #define Vsync_DM_OD_HI           PIN_DM_OD_HI
        #define Vsync_DM_STRONG          PIN_DM_STRONG
        #define Vsync_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Vsync_MASK               Vsync__MASK
#define Vsync_SHIFT              Vsync__SHIFT
#define Vsync_WIDTH              1u

/* Interrupt constants */
#if defined(Vsync__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Vsync_SetInterruptMode() function.
     *  @{
     */
        #define Vsync_INTR_NONE      (uint16)(0x0000u)
        #define Vsync_INTR_RISING    (uint16)(0x0001u)
        #define Vsync_INTR_FALLING   (uint16)(0x0002u)
        #define Vsync_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Vsync_INTR_MASK      (0x01u) 
#endif /* (Vsync__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Vsync_PS                     (* (reg8 *) Vsync__PS)
/* Data Register */
#define Vsync_DR                     (* (reg8 *) Vsync__DR)
/* Port Number */
#define Vsync_PRT_NUM                (* (reg8 *) Vsync__PRT) 
/* Connect to Analog Globals */                                                  
#define Vsync_AG                     (* (reg8 *) Vsync__AG)                       
/* Analog MUX bux enable */
#define Vsync_AMUX                   (* (reg8 *) Vsync__AMUX) 
/* Bidirectional Enable */                                                        
#define Vsync_BIE                    (* (reg8 *) Vsync__BIE)
/* Bit-mask for Aliased Register Access */
#define Vsync_BIT_MASK               (* (reg8 *) Vsync__BIT_MASK)
/* Bypass Enable */
#define Vsync_BYP                    (* (reg8 *) Vsync__BYP)
/* Port wide control signals */                                                   
#define Vsync_CTL                    (* (reg8 *) Vsync__CTL)
/* Drive Modes */
#define Vsync_DM0                    (* (reg8 *) Vsync__DM0) 
#define Vsync_DM1                    (* (reg8 *) Vsync__DM1)
#define Vsync_DM2                    (* (reg8 *) Vsync__DM2) 
/* Input Buffer Disable Override */
#define Vsync_INP_DIS                (* (reg8 *) Vsync__INP_DIS)
/* LCD Common or Segment Drive */
#define Vsync_LCD_COM_SEG            (* (reg8 *) Vsync__LCD_COM_SEG)
/* Enable Segment LCD */
#define Vsync_LCD_EN                 (* (reg8 *) Vsync__LCD_EN)
/* Slew Rate Control */
#define Vsync_SLW                    (* (reg8 *) Vsync__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Vsync_PRTDSI__CAPS_SEL       (* (reg8 *) Vsync__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Vsync_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Vsync__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Vsync_PRTDSI__OE_SEL0        (* (reg8 *) Vsync__PRTDSI__OE_SEL0) 
#define Vsync_PRTDSI__OE_SEL1        (* (reg8 *) Vsync__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Vsync_PRTDSI__OUT_SEL0       (* (reg8 *) Vsync__PRTDSI__OUT_SEL0) 
#define Vsync_PRTDSI__OUT_SEL1       (* (reg8 *) Vsync__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Vsync_PRTDSI__SYNC_OUT       (* (reg8 *) Vsync__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Vsync__SIO_CFG)
    #define Vsync_SIO_HYST_EN        (* (reg8 *) Vsync__SIO_HYST_EN)
    #define Vsync_SIO_REG_HIFREQ     (* (reg8 *) Vsync__SIO_REG_HIFREQ)
    #define Vsync_SIO_CFG            (* (reg8 *) Vsync__SIO_CFG)
    #define Vsync_SIO_DIFF           (* (reg8 *) Vsync__SIO_DIFF)
#endif /* (Vsync__SIO_CFG) */

/* Interrupt Registers */
#if defined(Vsync__INTSTAT)
    #define Vsync_INTSTAT            (* (reg8 *) Vsync__INTSTAT)
    #define Vsync_SNAP               (* (reg8 *) Vsync__SNAP)
    
	#define Vsync_0_INTTYPE_REG 		(* (reg8 *) Vsync__0__INTTYPE)
#endif /* (Vsync__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Vsync_H */


/* [] END OF FILE */
