/*******************************************************************************
* File Name: Raw_Vid.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Raw_Vid_H) /* Pins Raw_Vid_H */
#define CY_PINS_Raw_Vid_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Raw_Vid_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Raw_Vid__PORT == 15 && ((Raw_Vid__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    Raw_Vid_Write(uint8 value);
void    Raw_Vid_SetDriveMode(uint8 mode);
uint8   Raw_Vid_ReadDataReg(void);
uint8   Raw_Vid_Read(void);
void    Raw_Vid_SetInterruptMode(uint16 position, uint16 mode);
uint8   Raw_Vid_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the Raw_Vid_SetDriveMode() function.
     *  @{
     */
        #define Raw_Vid_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define Raw_Vid_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define Raw_Vid_DM_RES_UP          PIN_DM_RES_UP
        #define Raw_Vid_DM_RES_DWN         PIN_DM_RES_DWN
        #define Raw_Vid_DM_OD_LO           PIN_DM_OD_LO
        #define Raw_Vid_DM_OD_HI           PIN_DM_OD_HI
        #define Raw_Vid_DM_STRONG          PIN_DM_STRONG
        #define Raw_Vid_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define Raw_Vid_MASK               Raw_Vid__MASK
#define Raw_Vid_SHIFT              Raw_Vid__SHIFT
#define Raw_Vid_WIDTH              1u

/* Interrupt constants */
#if defined(Raw_Vid__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Raw_Vid_SetInterruptMode() function.
     *  @{
     */
        #define Raw_Vid_INTR_NONE      (uint16)(0x0000u)
        #define Raw_Vid_INTR_RISING    (uint16)(0x0001u)
        #define Raw_Vid_INTR_FALLING   (uint16)(0x0002u)
        #define Raw_Vid_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define Raw_Vid_INTR_MASK      (0x01u) 
#endif /* (Raw_Vid__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Raw_Vid_PS                     (* (reg8 *) Raw_Vid__PS)
/* Data Register */
#define Raw_Vid_DR                     (* (reg8 *) Raw_Vid__DR)
/* Port Number */
#define Raw_Vid_PRT_NUM                (* (reg8 *) Raw_Vid__PRT) 
/* Connect to Analog Globals */                                                  
#define Raw_Vid_AG                     (* (reg8 *) Raw_Vid__AG)                       
/* Analog MUX bux enable */
#define Raw_Vid_AMUX                   (* (reg8 *) Raw_Vid__AMUX) 
/* Bidirectional Enable */                                                        
#define Raw_Vid_BIE                    (* (reg8 *) Raw_Vid__BIE)
/* Bit-mask for Aliased Register Access */
#define Raw_Vid_BIT_MASK               (* (reg8 *) Raw_Vid__BIT_MASK)
/* Bypass Enable */
#define Raw_Vid_BYP                    (* (reg8 *) Raw_Vid__BYP)
/* Port wide control signals */                                                   
#define Raw_Vid_CTL                    (* (reg8 *) Raw_Vid__CTL)
/* Drive Modes */
#define Raw_Vid_DM0                    (* (reg8 *) Raw_Vid__DM0) 
#define Raw_Vid_DM1                    (* (reg8 *) Raw_Vid__DM1)
#define Raw_Vid_DM2                    (* (reg8 *) Raw_Vid__DM2) 
/* Input Buffer Disable Override */
#define Raw_Vid_INP_DIS                (* (reg8 *) Raw_Vid__INP_DIS)
/* LCD Common or Segment Drive */
#define Raw_Vid_LCD_COM_SEG            (* (reg8 *) Raw_Vid__LCD_COM_SEG)
/* Enable Segment LCD */
#define Raw_Vid_LCD_EN                 (* (reg8 *) Raw_Vid__LCD_EN)
/* Slew Rate Control */
#define Raw_Vid_SLW                    (* (reg8 *) Raw_Vid__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Raw_Vid_PRTDSI__CAPS_SEL       (* (reg8 *) Raw_Vid__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Raw_Vid_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Raw_Vid__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Raw_Vid_PRTDSI__OE_SEL0        (* (reg8 *) Raw_Vid__PRTDSI__OE_SEL0) 
#define Raw_Vid_PRTDSI__OE_SEL1        (* (reg8 *) Raw_Vid__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Raw_Vid_PRTDSI__OUT_SEL0       (* (reg8 *) Raw_Vid__PRTDSI__OUT_SEL0) 
#define Raw_Vid_PRTDSI__OUT_SEL1       (* (reg8 *) Raw_Vid__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Raw_Vid_PRTDSI__SYNC_OUT       (* (reg8 *) Raw_Vid__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(Raw_Vid__SIO_CFG)
    #define Raw_Vid_SIO_HYST_EN        (* (reg8 *) Raw_Vid__SIO_HYST_EN)
    #define Raw_Vid_SIO_REG_HIFREQ     (* (reg8 *) Raw_Vid__SIO_REG_HIFREQ)
    #define Raw_Vid_SIO_CFG            (* (reg8 *) Raw_Vid__SIO_CFG)
    #define Raw_Vid_SIO_DIFF           (* (reg8 *) Raw_Vid__SIO_DIFF)
#endif /* (Raw_Vid__SIO_CFG) */

/* Interrupt Registers */
#if defined(Raw_Vid__INTSTAT)
    #define Raw_Vid_INTSTAT            (* (reg8 *) Raw_Vid__INTSTAT)
    #define Raw_Vid_SNAP               (* (reg8 *) Raw_Vid__SNAP)
    
	#define Raw_Vid_0_INTTYPE_REG 		(* (reg8 *) Raw_Vid__0__INTTYPE)
#endif /* (Raw_Vid__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Raw_Vid_H */


/* [] END OF FILE */
