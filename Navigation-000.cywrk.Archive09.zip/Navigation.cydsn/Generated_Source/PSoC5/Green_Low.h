/*******************************************************************************
* File Name: Green_Low.h
* Version 1.71
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_Green_Low_H)
#define CY_ISR_Green_Low_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void Green_Low_Start(void);
void Green_Low_StartEx(cyisraddress address);
void Green_Low_Stop(void);

CY_ISR_PROTO(Green_Low_Interrupt);

void Green_Low_SetVector(cyisraddress address);
cyisraddress Green_Low_GetVector(void);

void Green_Low_SetPriority(uint8 priority);
uint8 Green_Low_GetPriority(void);

void Green_Low_Enable(void);
uint8 Green_Low_GetState(void);
void Green_Low_Disable(void);

void Green_Low_SetPending(void);
void Green_Low_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the Green_Low ISR. */
#define Green_Low_INTC_VECTOR            ((reg32 *) Green_Low__INTC_VECT)

/* Address of the Green_Low ISR priority. */
#define Green_Low_INTC_PRIOR             ((reg8 *) Green_Low__INTC_PRIOR_REG)

/* Priority of the Green_Low interrupt. */
#define Green_Low_INTC_PRIOR_NUMBER      Green_Low__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable Green_Low interrupt. */
#define Green_Low_INTC_SET_EN            ((reg32 *) Green_Low__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the Green_Low interrupt. */
#define Green_Low_INTC_CLR_EN            ((reg32 *) Green_Low__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the Green_Low interrupt state to pending. */
#define Green_Low_INTC_SET_PD            ((reg32 *) Green_Low__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the Green_Low interrupt. */
#define Green_Low_INTC_CLR_PD            ((reg32 *) Green_Low__INTC_CLR_PD_REG)


#endif /* CY_ISR_Green_Low_H */


/* [] END OF FILE */
