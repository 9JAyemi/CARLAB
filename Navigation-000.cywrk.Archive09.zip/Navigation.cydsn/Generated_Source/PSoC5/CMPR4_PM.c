/*******************************************************************************
* File Name: CMPR4.c
* Version 2.0
*
* Description:
*  This file provides the power management source code APIs for the
*  Comparator.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CMPR4.h"

static CMPR4_backupStruct CMPR4_backup;


/*******************************************************************************
* Function Name: CMPR4_SaveConfig
********************************************************************************
*
* Summary:
*  Save the current user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
*******************************************************************************/
void CMPR4_SaveConfig(void) 
{
    /* Empty since all are system reset for retention flops */
}


/*******************************************************************************
* Function Name: CMPR4_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
********************************************************************************/
void CMPR4_RestoreConfig(void) 
{
    /* Empty since all are system reset for retention flops */    
}


/*******************************************************************************
* Function Name: CMPR4_Sleep
********************************************************************************
*
* Summary:
*  Stop and Save the user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
* Global variables:
*  CMPR4_backup.enableState:  Is modified depending on the enable 
*   state of the block before entering sleep mode.
*
*******************************************************************************/
void CMPR4_Sleep(void) 
{
    /* Save Comp's enable state */    
    if(CMPR4_ACT_PWR_EN == (CMPR4_PWRMGR & CMPR4_ACT_PWR_EN))
    {
        /* Comp is enabled */
        CMPR4_backup.enableState = 1u;
    }
    else
    {
        /* Comp is disabled */
        CMPR4_backup.enableState = 0u;
    }    
    
    CMPR4_Stop();
    CMPR4_SaveConfig();
}


/*******************************************************************************
* Function Name: CMPR4_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  CMPR4_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void CMPR4_Wakeup(void) 
{
    CMPR4_RestoreConfig();
    
    if(CMPR4_backup.enableState == 1u)
    {
        /* Enable Comp's operation */
        CMPR4_Enable();

    } /* Do nothing if Comp was disabled before */ 
}


/* [] END OF FILE */
