/*******************************************************************************
* File Name: CMPR.c
* Version 2.0
*
* Description:
*  This file provides the power management source code APIs for the
*  Comparator.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CMPR.h"

static CMPR_backupStruct CMPR_backup;


/*******************************************************************************
* Function Name: CMPR_SaveConfig
********************************************************************************
*
* Summary:
*  Save the current user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
*******************************************************************************/
void CMPR_SaveConfig(void) 
{
    /* Empty since all are system reset for retention flops */
}


/*******************************************************************************
* Function Name: CMPR_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
********************************************************************************/
void CMPR_RestoreConfig(void) 
{
    /* Empty since all are system reset for retention flops */    
}


/*******************************************************************************
* Function Name: CMPR_Sleep
********************************************************************************
*
* Summary:
*  Stop and Save the user configuration
*
* Parameters:
*  void:
*
* Return:
*  void
*
* Global variables:
*  CMPR_backup.enableState:  Is modified depending on the enable 
*   state of the block before entering sleep mode.
*
*******************************************************************************/
void CMPR_Sleep(void) 
{
    /* Save Comp's enable state */    
    if(CMPR_ACT_PWR_EN == (CMPR_PWRMGR & CMPR_ACT_PWR_EN))
    {
        /* Comp is enabled */
        CMPR_backup.enableState = 1u;
    }
    else
    {
        /* Comp is disabled */
        CMPR_backup.enableState = 0u;
    }    
    
    CMPR_Stop();
    CMPR_SaveConfig();
}


/*******************************************************************************
* Function Name: CMPR_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  CMPR_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void CMPR_Wakeup(void) 
{
    CMPR_RestoreConfig();
    
    if(CMPR_backup.enableState == 1u)
    {
        /* Enable Comp's operation */
        CMPR_Enable();

    } /* Do nothing if Comp was disabled before */ 
}


/* [] END OF FILE */
