/*******************************************************************************
* File Name: capture.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_capture_H) /* Pins capture_H */
#define CY_PINS_capture_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "capture_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 capture__PORT == 15 && ((capture__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    capture_Write(uint8 value);
void    capture_SetDriveMode(uint8 mode);
uint8   capture_ReadDataReg(void);
uint8   capture_Read(void);
void    capture_SetInterruptMode(uint16 position, uint16 mode);
uint8   capture_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the capture_SetDriveMode() function.
     *  @{
     */
        #define capture_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define capture_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define capture_DM_RES_UP          PIN_DM_RES_UP
        #define capture_DM_RES_DWN         PIN_DM_RES_DWN
        #define capture_DM_OD_LO           PIN_DM_OD_LO
        #define capture_DM_OD_HI           PIN_DM_OD_HI
        #define capture_DM_STRONG          PIN_DM_STRONG
        #define capture_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define capture_MASK               capture__MASK
#define capture_SHIFT              capture__SHIFT
#define capture_WIDTH              1u

/* Interrupt constants */
#if defined(capture__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in capture_SetInterruptMode() function.
     *  @{
     */
        #define capture_INTR_NONE      (uint16)(0x0000u)
        #define capture_INTR_RISING    (uint16)(0x0001u)
        #define capture_INTR_FALLING   (uint16)(0x0002u)
        #define capture_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define capture_INTR_MASK      (0x01u) 
#endif /* (capture__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define capture_PS                     (* (reg8 *) capture__PS)
/* Data Register */
#define capture_DR                     (* (reg8 *) capture__DR)
/* Port Number */
#define capture_PRT_NUM                (* (reg8 *) capture__PRT) 
/* Connect to Analog Globals */                                                  
#define capture_AG                     (* (reg8 *) capture__AG)                       
/* Analog MUX bux enable */
#define capture_AMUX                   (* (reg8 *) capture__AMUX) 
/* Bidirectional Enable */                                                        
#define capture_BIE                    (* (reg8 *) capture__BIE)
/* Bit-mask for Aliased Register Access */
#define capture_BIT_MASK               (* (reg8 *) capture__BIT_MASK)
/* Bypass Enable */
#define capture_BYP                    (* (reg8 *) capture__BYP)
/* Port wide control signals */                                                   
#define capture_CTL                    (* (reg8 *) capture__CTL)
/* Drive Modes */
#define capture_DM0                    (* (reg8 *) capture__DM0) 
#define capture_DM1                    (* (reg8 *) capture__DM1)
#define capture_DM2                    (* (reg8 *) capture__DM2) 
/* Input Buffer Disable Override */
#define capture_INP_DIS                (* (reg8 *) capture__INP_DIS)
/* LCD Common or Segment Drive */
#define capture_LCD_COM_SEG            (* (reg8 *) capture__LCD_COM_SEG)
/* Enable Segment LCD */
#define capture_LCD_EN                 (* (reg8 *) capture__LCD_EN)
/* Slew Rate Control */
#define capture_SLW                    (* (reg8 *) capture__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define capture_PRTDSI__CAPS_SEL       (* (reg8 *) capture__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define capture_PRTDSI__DBL_SYNC_IN    (* (reg8 *) capture__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define capture_PRTDSI__OE_SEL0        (* (reg8 *) capture__PRTDSI__OE_SEL0) 
#define capture_PRTDSI__OE_SEL1        (* (reg8 *) capture__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define capture_PRTDSI__OUT_SEL0       (* (reg8 *) capture__PRTDSI__OUT_SEL0) 
#define capture_PRTDSI__OUT_SEL1       (* (reg8 *) capture__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define capture_PRTDSI__SYNC_OUT       (* (reg8 *) capture__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(capture__SIO_CFG)
    #define capture_SIO_HYST_EN        (* (reg8 *) capture__SIO_HYST_EN)
    #define capture_SIO_REG_HIFREQ     (* (reg8 *) capture__SIO_REG_HIFREQ)
    #define capture_SIO_CFG            (* (reg8 *) capture__SIO_CFG)
    #define capture_SIO_DIFF           (* (reg8 *) capture__SIO_DIFF)
#endif /* (capture__SIO_CFG) */

/* Interrupt Registers */
#if defined(capture__INTSTAT)
    #define capture_INTSTAT            (* (reg8 *) capture__INTSTAT)
    #define capture_SNAP               (* (reg8 *) capture__SNAP)
    
	#define capture_0_INTTYPE_REG 		(* (reg8 *) capture__0__INTTYPE)
#endif /* (capture__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_capture_H */


/* [] END OF FILE */
