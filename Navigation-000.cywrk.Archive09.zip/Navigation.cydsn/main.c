/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/


//Nav Code:
#include "project.h"
#include <stdio.h>

//Pi Variables
uint8 greenState;
uint8 redState;
uint8 yellowState;



//Speed Control Variables
uint16 new_time; 
uint16 old_time = 65535;
uint16 elapsed; // Shows how much time has passed
double speed; // Speed of the car
double MOTOR_PWM;   // Pulse Width Modulation
double MOTOR_PWM_base = 0; /*Base PWM value for motor calculation*/
double kp_motor = 15; // proportional gain for motor
char strbuf[64];

//Navigation Variables
double kp_servo = -0.1;  /* negative to move back towards line*/
uint16 current_time;
double nav_error;
double SERVO_PWM; 
double SERVO_PWM_base = 125; // Base PWM for navigation servo 
uint16 nav_time; 
double NAV_GOAL = 850; // initial nav time when car is placed on track 



/*CY_ISR(inter3){
    // Inside your ISR or main code
greenState = Green_DIG_Read();    // Reads the state of Green_Pi pin (1 if high, 0 if low)
redState = Red_DIG_Read();        // Reads the state of Red_Pi pin
yellowState = Yellow_DIG_Read();  // Reads the state of Yellow_Pi pin
    if (Green_Pi_Read() == 1) {
    MOTOR_PWM = MOTOR_PWM_base; 
    UART_PutString("Green signal detected. PWM = default.\n");
} else if (redState == 1) {
    MOTOR_PWM = 0;
    UART_PutString("Red signal detected. Motor stopped.\n");
} else if (yellowState == 1) {
    MOTOR_PWM = 5;
    UART_PutString("Yellow signal detected. PWM = 5.\n");
} else {  
    MOTOR_PWM = MOTOR_PWM_base;
    UART_PutString("No signal detected. Default PWM applied.\n");
}
}*/

//High States
CY_ISR(inter0){
    greenState = 1;
    UART_PutString("Green signal detected. \n");
}

CY_ISR(inter1){
    redState = 1;
    UART_PutString("Red signal detected. \n");
}
CY_ISR(inter2){
    yellowState = 1;
    UART_PutString("Yellow signal detected. \n");
}

//Low States
CY_ISR(inter3){
    greenState = 0;
    UART_PutString("Green signal not detected. \n");
}

CY_ISR(inter4){
    redState = 0;
    UART_PutString("Red signal not detected. \n");
}
CY_ISR(inter5){
    yellowState = 0;
    UART_PutString("Yellow signal not detected. \n");
}



// Interrupt for Navigation
CY_ISR(inter){
    nav_time = 65535 - Timer_ReadCapture(); // changes when camera sees white (when you go off the line)
    // UART_PutString("Nav Works. \n");
    // Navigation correction code
    nav_error = NAV_GOAL - nav_time; // calculates error whenever camera sees white 
       SERVO_PWM = SERVO_PWM_base + kp_servo * nav_error; // corrects PWM based on whether car is on track or not 
   // Resets PWM depending on current value //
    if (SERVO_PWM > 250) SERVO_PWM = 250;
    if (SERVO_PWM < 2) SERVO_PWM = 2;
        SERVO_PWM_WriteCompare( (uint8) SERVO_PWM);
    Timer_ReadStatusRegister();
}

/*
// Interrupt for Speed Control
CY_ISR(inter2){
    // Elapsed time calc //
    new_time = Timer2_ReadCapture();
    
    if (old_time >= new_time)
        elapsed = old_time - new_time;
    else
        elapsed = 65535 - new_time + old_time;
    
    // Speed Calculation //
    speed = 1256.0/ (double) elapsed;
    
    // PWM Calculation //
    MOTOR_PWM = MOTOR_PWM_base + kp_motor * (4-speed);
    
// Prints out current speed and PWM of car
    sprintf(strbuf, "\r\n %f %f ", speed, MOTOR_PWM);
    UART_PutString(strbuf);
   UART_PutString("\r\n**********************************");
    
    // Reset PWM depending on current value
    if (MOTOR_PWM > 200)
            MOTOR_PWM = 200;
   if (MOTOR_PWM < 20){
        MOTOR_PWM = 20;
}
    MOTOR_PWM_WriteCompare((uint8)MOTOR_PWM);
    old_time = new_time;

    Timer2_ReadStatusRegister();
   }
*/

// Main 
int main(void)
{
    MOTOR_PWM_WriteCompare((uint8)MOTOR_PWM_base);
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Initialization Code */

    SERVO_PWM_Start(); 
    Timer_Start();
    UART_Start();
    DAC_Start();
    CMPR_Start();
    Nav_ISR_Start();
   Nav_ISR_SetVector(inter);
    MOTOR_PWM_Start();
    Timer2_Start();
   // HE_isr_Start();
  //  HE_isr_SetVector(inter2);
    DAC2_Start();
    CMPR2_Start();
    CMPR3_Start();
    CMPR4_Start();
    //Pi_ISR_Start();
   // Pi_ISR_SetVector(inter3);
    Green_High_Start();
    Green_High_SetVector(inter0);
    Red_High_Start();
    Red_High_SetVector(inter1);
    Yellow_High_Start();
    Yellow_High_SetVector(inter2);
    
    Green_Low_Start();
    Green_Low_SetVector(inter3);
    Red_Low_Start();
    Red_Low_SetVector(inter4);
    Yellow_Low_Start();
    Yellow_Low_SetVector(inter5);
    
    
    for(;;) {
        // UART_PutString("hi! \n");
       
   if (redState){
   // MOTOR_PWM = 0;
    MOTOR_PWM_WriteCompare((uint8)0);
}
else if (yellowState) {
  //  MOTOR_PWM = 7;
    MOTOR_PWM_WriteCompare((uint8)20);
}
else if (greenState) {
  //  MOTOR_PWM = 30;
    MOTOR_PWM_WriteCompare((uint8)35);
}

}
}

/* [] END OF FILE */



